<?php

namespace up;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\math\Vector3;

class up extends PluginBase implements Listener {
public function onEnable() {
$this->getServer ()->getPluginManager ()->registerEvents ( $this, $this );
}
public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
$cmd = $command->getName ();
$p = $sender->getPlayer ();
if ($cmd == "up"){
if( ! isset($args[0]) ){
$p->sendMessage("/up <number> to go that height and create a glass block under the player's feet.");
return true;
}
if(!is_numeric($args[0])){
$p->sendMessage("Please write a number.");
return true;
}
$y = intval($p->y);
if(($y + $args[0]) > 256){
$p->sendMessage("The height limit is greater than the number you enter (maximum: 256 blocks).");
return true;
}
if($args[0] < 0){
$p->sendMessage($t."Please write 0 or higher.");
return true;
}
$y = $p->getY();
$p->teleport(new Position(floatval($p->x), floatval($p->y) + 
$args[0], floatval($p->z), $p->getLevel()));
$p->getLevel()->setBlock(new Vector3($p->getX(), $p->getY() -1,
$p->getZ()), Block::get(20));
$p->sendMessage("§b§l{$args[0]}It's gone up a lot.");
}
if ($cmd == "/top"){
$y = $p->getY();
$p->teleport(new Vector3($p->getX(), $p->getLevel()->getHighestBlockAt($p->getFloorX(), $p->getFloorZ()) + 1, $p->getZ()));
$p->sendMessage("We went up to the roof of the block.");
}
return true;
}
}